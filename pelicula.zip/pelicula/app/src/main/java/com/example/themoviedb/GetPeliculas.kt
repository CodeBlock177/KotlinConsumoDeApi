package com.example.themoviedb

import com.google.gson.annotations.SerializedName

data class GetPeliculas(
    @SerializedName("page") val page: Int,
    @SerializedName("results") val movies: List<Peliculas>,
    @SerializedName("total_pages") val pages: Int
)
