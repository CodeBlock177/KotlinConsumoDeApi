package com.example.themoviedb

class Constantes {

    companion object{
        const val APIKEY = "86cbedace2010b80127773f9553cc5b6"

        const val BASE_URL = "https://api.themoviedb.org/3/"

        const val FONDO = "fondo de pelicula"
        const val POSTER = "poster de pelicula"
        const val TITULO = "titulo"
        const val CLASIFICACION = "Clasificacion"
        const val FECHA = "Fecha"
        const val GENERAL = "General"
    }
}