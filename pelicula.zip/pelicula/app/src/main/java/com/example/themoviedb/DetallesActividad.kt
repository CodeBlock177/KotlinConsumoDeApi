package com.example.themoviedb


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.example.themoviedb.Constantes.Companion.FONDO
import com.example.themoviedb.Constantes.Companion.GENERAL
import com.example.themoviedb.Constantes.Companion.POSTER
import com.example.themoviedb.Constantes.Companion.CLASIFICACION
import com.example.themoviedb.Constantes.Companion.FECHA
import com.example.themoviedb.Constantes.Companion.TITULO
import com.example.themoviedb.databinding.ActivityDetallesBinding


class DetallesActividad : AppCompatActivity() {

    private lateinit var binding: ActivityDetallesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetallesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val extras = intent.extras

        if (extras != null) {
            populateDetails(extras)
        } else {
            finish()
        }
    }

    private fun populateDetails(extras: Bundle) {
        extras.getString(FONDO)?.let { backdropPath ->
            Glide.with(this)
                .load("https://image.tmdb.org/t/p/w1280$backdropPath")
                .transform(CenterCrop())
                .into(binding.movieBackdrop)
        }

        extras.getString(POSTER)?.let { posterPath ->
            Glide.with(this)
                .load("https://image.tmdb.org/t/p/w342$posterPath")
                .transform(CenterCrop())
                .into(binding.moviePoster)
        }

        binding.movieTitle.text = extras.getString(TITULO, "")
        binding.movieRating.rating = extras.getFloat(CLASIFICACION, 0f) / 2
        binding.movieReleaseDate.text = extras.getString(FECHA, "")
        binding.movieOverview.text = extras.getString(GENERAL, "")
    }
    }
